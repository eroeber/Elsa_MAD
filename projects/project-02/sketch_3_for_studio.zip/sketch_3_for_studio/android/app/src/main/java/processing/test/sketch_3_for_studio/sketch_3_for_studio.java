package processing.test.sketch_3_for_studio;

import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_3_for_studio extends PApplet {

//var slider;

int number;
int radius = 10;
float stepSize = 0.5f;
int opacity = 200;
boolean animate = true;
int time = 0;

public void setup(){
  // size(displayWidth, displayHeight, P3D);
  noStroke();      
  
  //slider = createSlider(2, 25, 10);
  //slider.position(width/2, 10);

}

public void draw(){
  background(100);
  fill(97,209,246,opacity);
  translate(width / 2, height / 2);
  if (animate == true){
    number = frameCount;
  }
  float goldenAngle = PI * (3.0f - sqrt(5));
  
  rotate(time);
  
  for (int i = 0; i < number; i++) {
    translate(0, i * stepSize);
    rotate(goldenAngle);

    // draw ellipse
    //int val = slider.value();
    ellipse(0, 0, radius, radius);

  }
  time += 0.01f;                                
}
}
